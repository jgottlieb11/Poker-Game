public class PokerTest {
    public static void main(String[] args) {
        Game pokerGame = new Game();
        pokerGame.play();
    }
}